export interface PricingPlan {
  id: string;
  name: string;
  billingCycle: string;
  pricePerMonth: string; // e.g. "RM ---"
  totalPrice: string;    // e.g. "RM ---"
  discountBadge?: string;
  isPopular?: boolean;
  deviceLimit: string;
  trafficLimit: string;
  refundPolicy: string;
  supportLevel: string;
  features: string[];
  statusMessage: string;
}

export const pricingConfig = {
  currencySymbol: 'RM',
  isConfirmed: false,
  unconfirmedNote: 'Pricing to be confirmed / 价格以正式上线公示为准',
  plans: [
    {
      id: 'monthly',
      name: '1个月套餐',
      billingCycle: '按月计费',
      pricePerMonth: 'RM ---',
      totalPrice: 'RM ---',
      deviceLimit: '支持 5 台设备同时连接',
      trafficLimit: '无流量限制 / 极速隧道',
      refundPolicy: '3 天无条件退款保障',
      supportLevel: '标准工单与在线客服',
      features: [
        '全平台客户端支持',
        '全球 60+ 地区节点选路',
        'AES-256 高强度隧道加密',
        '自动智能选路节点',
      ],
      statusMessage: '适合短期试用与临时使用需求',
    },
    {
      id: 'halfyear',
      name: '6个月套餐',
      billingCycle: '每 6 个月计费一次',
      pricePerMonth: 'RM ---',
      totalPrice: 'RM ---',
      discountBadge: '省心推荐',
      deviceLimit: '支持 7 台设备同时连接',
      trafficLimit: '无流量限制 / 极速隧道',
      refundPolicy: '7 天无条件退款保障',
      supportLevel: '优先响应客服支持',
      features: [
        '全平台客户端支持',
        '全球 60+ 地区节点选路',
        'AES-256 高强度隧道加密',
        '专线优化及流媒体解封',
        'Smart Connection 智能选路',
      ],
      statusMessage: '平衡灵活性与长期稳定体验',
    },
    {
      id: 'annual',
      name: '12个月套餐',
      billingCycle: '按年计费',
      pricePerMonth: 'RM ---',
      totalPrice: 'RM ---',
      discountBadge: '超值首选 (推荐)',
      isPopular: true,
      deviceLimit: '支持 10 台设备同时连接',
      trafficLimit: '无流量限制 / 极速隧道',
      refundPolicy: '30 天无条件退款保障',
      supportLevel: '24/7 专属优先技术支持',
      features: [
        '全平台客户端支持',
        '全球 60+ 地区节点选路',
        'AES-256 高强度隧道加密',
        '游戏低延迟专线与流媒体优化',
        '全自动智能选路与 Kill Switch',
        '公共 Wi-Fi 自动防护引擎',
      ],
      statusMessage: '最具性价比的长期稳定连接方案',
    },
  ] as PricingPlan[],
};
