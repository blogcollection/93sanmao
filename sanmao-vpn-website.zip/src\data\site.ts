export interface MetricItem {
  value: string;
  label: string;
  sublabel: string;
  isDemo?: boolean;
}

export interface SiteConfig {
  brandName: string;
  brandNameEn: string;
  tagline: string;
  description: string;
  url: string;
  contactEmail: string;
  isDemoMode: boolean;
  metrics: MetricItem[];
}

export const siteConfig: SiteConfig = {
  brandName: '三毛',
  brandNameEn: 'SANMAO',
  tagline: '连接世界。简单一点。',
  description: '面向中文用户的现代 VPN / 全球网络加速服务。提供极速、稳定且安全的网络隧道连接。',
  url: 'https://sanmao.cfd',
  contactEmail: 'support@sanmao.cfd',
  isDemoMode: true,
  metrics: [
    {
      value: '60+',
      label: '覆盖地区',
      sublabel: '全球主流节点网络',
      isDemo: true,
    },
    {
      value: '100+',
      label: '高规格服务器',
      sublabel: '多路冗余带宽链路',
      isDemo: true,
    },
    {
      value: '99.9%',
      label: '服务可用性',
      sublabel: ' SLA 级持续在线保护',
      isDemo: true,
    },
    {
      value: '24/7',
      label: '技术支持',
      sublabel: '在线客服与工单支持',
      isDemo: true,
    },
  ],
};

export const linksConfig = {
  downloadWindows: '#download-windows-placeholder',
  downloadMac: '#download-mac-placeholder',
  downloadIos: '#download-ios-placeholder',
  downloadAndroid: '#download-android-placeholder',
  downloadLinux: '#download-linux-placeholder',
  login: '#login-placeholder',
  signup: '#signup-placeholder',
  statusPage: '#status-placeholder',
  support: '/support',
  privacy: '/privacy-placeholder',
  terms: '/terms-placeholder',
};
