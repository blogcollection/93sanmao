# PLACEHOLDER_DATA.md — 待补充真实商业资料清单

根据设计指示，本项目严禁自动捏造虚假商业资料。所有目前为 Demo / 示例性质的数据已独立抽离至 `src/data/*.ts`，并在前端界面明确标注了 Demo/Pending 标识。上线前请协助提供并替换以下真实商业资料：

---

## 01｜订阅价格与商业方案 (`src/data/pricing.ts`)

| 数据项 | 当前页面显示状态 | 需要提供的真实商业资料 |
| :--- | :--- | :--- |
| **月付价格** | `RM ---` (Pricing to be confirmed) | 1个月套餐的真实标价与结算货币单位 |
| **6个月套餐价格** | `RM ---` (Pricing to be confirmed) | 6个月套餐的总价与月均划算价格 |
| **12个月套餐价格** | `RM ---` (Pricing to be confirmed) | 12个月套餐的总价与优惠折扣力度 |
| **退款保障期限** | 示例 3-30 天 | 商业法务确定的实际无条件退款保障天数 |
| **同时连接设备数** | 示例 5 - 10 台 | 实际单个账号允许同时连接的上限台数 |

---

## 02｜服务器节点与网络数据 (`src/data/servers.ts`)

| 数据项 | 当前页面显示状态 | 需要提供的真实商业资料 |
| :--- | :--- | :--- |
| **实际覆盖国家与城市** | 示例 10 个节点 (新加坡、东京、香港等) | 实际部署上线的所有机房与节点列表 |
| **服务器总数量** | 示例 "100+ 高规格服务器" | 真实的专线与节点总数 |
| **实时测速与 Ping 值** | 示例 "28 ms / Demo Visualization" | 接入真实前端 Ping 测速 API 或后台真实数据 |

---

## 03｜下载与平台链接 (`src/data/site.ts`)

| 数据项 | 当前占位锚点 | 需要提供的真实商业资料 |
| :--- | :--- | :--- |
| **Windows 客户端下载** | `#download-windows-placeholder` | 真实 Windows `.exe` / `.msi` 安装包下载 URL |
| **macOS 客户端下载** | `#download-mac-placeholder` | 真实 macOS `.dmg` / `.pkg` 安装包下载 URL |
| **iOS 客户端链接** | `#download-ios-placeholder` | 真实 App Store 应用商店链接 |
| **Android 客户端下载** | `#download-android-placeholder` | 真实 Google Play 链接或 APK 直链 |
| **Linux 客户端下载** | `#download-linux-placeholder` | 真实 Linux Shell 脚本或 `.deb`/`.rpm` 包链接 |

---

## 04｜账户系统与服务支持 (`src/data/site.ts`)

| 数据项 | 当前占位锚点 | 需要提供的真实商业资料 |
| :--- | :--- | :--- |
| **用户登录 URL** | `#login-placeholder` | 用户 Dashboard / 登录页面的真实入口 URL |
| **用户注册 URL** | `#signup-placeholder` | 用户注册/结账入口 URL |
| **技术支持邮箱** | `support@sanmao.cfd` | 实际接收客户工单的客服邮箱 |
| **在线客服系统** | HTML 按钮预留 | 第三方在线客服 (如 Crisp, Intercom, LiveChat) 嵌入代码 |

---

## 05｜公司合规与法务文档

| 数据项 | 当前页面显示状态 | 需要提供的真实商业资料 |
| :--- | :--- | :--- |
| **运营公司名称与注册地址** | Documentation in preparation | 实际法律运营实体公司名及注册地 |
| **无日志 (No-Logs) 声明** | Pending Product Verification | 法务与技术团队确认的隐私无日志审计文件 |
| **隐私政策 (Privacy Policy)** | `/privacy-placeholder` | 完整的隐私政策 Markdown/HTML 文本 |
| **服务条款 (Terms of Service)**| `/terms-placeholder` | 完整的服务条款 Markdown/HTML 文本 |
