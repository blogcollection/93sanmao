# DESIGN_AUDIT.md — 三毛 (SANMAO) 官网设计审计报告

## 01｜全局设计系统审查 (Global Design System Audit)

| 视角/维度 | 规范设定 | 实际落地情况 | 偏离度及理由 |
| :--- | :--- | :--- | :--- |
| **配色比例** | 90% 黑/白/灰 + 10% 品牌色 (`#00A88F`) | `src/styles/global.css` 及 `tailwind.config.cjs` 严格定义品牌色 `#00A88F`，仅用于 CTA、节点状态、动画 Pulse 及少量核心数据。 | 0% 无偏离 |
| **字体与排版** | Inter, Noto Sans SC, system-ui | 字体栈统一设为 Inter与Noto Sans SC，H1 使用 clamp 响应式大字，短标题极简叙事。 | 0% 无偏离 |
| **Navbar 规范** | 高度 56-64px, `rgba(255,255,255,0.82)`, `backdrop-blur` | `src/components/Navbar.astro` 采用 Apple 式极简半透明 Sticky 头部，小型圆角 CTA，未使用大阴影或复杂胶囊 UI。 | 0% 无偏离 |
| **Hero 布局** | 无人像照片、无锁头/盾牌，中央 UI Display | `src/components/Hero.astro` 居中叙事，展示 SANMAO Connection Interface 动态 UI 界面，包含新加坡 28ms 状态。 | 0% 无偏离 |
| **黑白 Section 节奏** | 严格交替黑/白/灰 | 首页依次为：White (Hero/Metrics) → Black (Network) → White (Speed) → Light Gray (Smart Connection) → Black (Devices) → Dark (Security) → Light Gray/Black (Use Cases) → Black (Performance) → White (Pricing) → Light Gray (Trust/FAQ) → Black (Final CTA)。 | 0% 无偏离 |
| **视觉禁忌排除** | 严禁 Glassmorphism、Neon、Glow、Emoji、Card Grid 堆叠 | 全站使用矢量 SVG、纯 Typography、自制通用设备框及底图衬托，0 个 Emoji，0 个炫彩渐变卡片。 | 0% 无偏离 |

---

## 02｜响应式断点自查 (Responsive Breakpoint Audit)

全站经响应式测试，适配以下标准分辨率：
- **1920px (Desktop Large)**：容器最大宽度 1200px 居中，大 Typography 视觉对齐。
- **1440px (Desktop Medium)**：Hero H1 保持 clamp(64px, 7vw, 112px)，换行自然无溢出。
- **1024px (Tablet Landscape)**：网格自动降级为 2 列，图文混排保持平衡。
- **768px (Tablet Portrait)**：Navbar 自动切换为极简 Hamburger Menu，按钮无挤压。
- **430px / 390px / 375px (Mobile Standard)**：
  - 中文 H1 最多 3 行，无强制截断；
  - 设备 App Mockup 自适应缩小；
  - 无横向滚动条 (Overflow-x: hidden 强制防护)；
  - Footer 与 FAQ 伸缩正常。

---

## 03｜组件与技术独立性

- 0 个第三方 API 强依赖；
- 0 个付费图标库依赖；
- 全部视觉元素由 SVG 与 Tailwind CSS 纯代构建；
- SSG 编译打包后生成纯静态 HTML/CSS/JS 文件，可零配置部署至 Cloudflare Pages。
